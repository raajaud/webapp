<?php $__env->startSection('content'); ?>

<style>

h3 {
  margin: 0;
  padding: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  color: black;
  font-family: Times New Roman, serif;
  /* background: -webkit-linear-gradient(deeppink, yellow, deeppink, purple);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent; */
  font-size: 6.5vw;
  /* text-transform: uppercase; */
}
h3:before {
  content: attr(data-text);
  position: absolute;
  top: 0;
  left: 0;
  transform-origin: bottom;
  transform: rotateX(180deg);
  line-height: 1.14em;
 background: linear-gradient(0deg, #000000 0, transparent 70%);
    -webkit-background-clip: text;
  -webkit-text-color: transparent;
  opacity: 0.3;
}
header {
  display: block;
  text-align: center;
  line-height: 1.5em;
  margin: 50px;
  font-size: 2vw;
  background: linear-gradient(deeppink, purple, yellow, purple);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  
}
</style>
<div class="wrapper">
  <h3 data-text="Coming soon...">Coming soon...</h3>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webapp\resources\views/welcome.blade.php ENDPATH**/ ?>