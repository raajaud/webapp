<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\webapp\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>